package com.mycompany.taskmanager.resources;

import com.mycompany.management.model.Project;
import com.mycompany.management.model.Task;
import com.mycompany.taskmanager.services.ManagementService;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/management")
public class ManagementResource {
    private final ManagementService service = new ManagementService();
    private static final String API_KEY = "1234";

    private boolean isValidApiKey(String apiKey) {
        return API_KEY.equals(apiKey);
    }

    @GET
    @Path("/projects")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllProjects() {
        return Response.ok(service.getAllProjects()).build();
    }

    @POST
    @Path("/projects")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createProject(Project project, @HeaderParam("API-Key") String apiKey) {
        if (!isValidApiKey(apiKey)) {
            return Response.status(Response.Status.FORBIDDEN).build();
        }
        service.createProject(project);
        return Response.status(Response.Status.CREATED).entity("Project created successfully").build();
    }

    @DELETE
    @Path("/projects/{id}")
    public Response deleteProject(@PathParam("id") int projectId, @HeaderParam("API-Key") String apiKey) {
        if (!isValidApiKey(apiKey)) {
            return Response.status(Response.Status.FORBIDDEN).build();
        }
        service.deleteProject(projectId);
        return Response.ok("Project deleted successfully").build();
    }

    @POST
    @Path("/projects/{projectId}/tasks")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createTask(@PathParam("projectId") int projectId, Task task, @HeaderParam("API-Key") String apiKey) {
        if (!isValidApiKey(apiKey)) {
            return Response.status(Response.Status.FORBIDDEN).build();
        }
        service.createTask(projectId, task);
        return Response.status(Response.Status.CREATED).entity("Task created successfully").build();
    }

    @GET
    @Path("/tasks")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllTasks() {
        List<Task> allTasks = service.getAllProjects().stream()
                .flatMap(project -> project.getTasks().stream())
                .toList();
        return Response.ok(allTasks).build();
    }
}
