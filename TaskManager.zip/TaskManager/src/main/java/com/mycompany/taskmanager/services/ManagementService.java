package com.mycompany.taskmanager.services;

import com.mycompany.management.model.Project;
import com.mycompany.management.model.Task;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ManagementService {
    private final Map<Integer, Project> projects = new HashMap<>();
    private int nextProjectId = 1;
    private int nextTaskId = 1;

    public List<Project> getAllProjects() {
        return new ArrayList<>(projects.values());
    }

    public Project getProjectById(int projectId) {
        return projects.get(projectId);
    }

    public void createProject(Project project) {
        project.setProjectId(nextProjectId++);
        projects.put(project.getProjectId(), project);
    }

    public void updateProject(int projectId, String name, String description) {
        Project project = projects.get(projectId);
        if (project != null) {
            project.setName(name);
            project.setDescription(description);
        }
    }

    public void deleteProject(int projectId) {
        projects.remove(projectId);
    }

    public List<Task> getTasksByProjectId(int projectId) {
        Project project = projects.get(projectId);
        return project != null ? project.getTasks() : new ArrayList<>();
    }

    public void createTask(int projectId, Task task) {
        Project project = projects.get(projectId);
        if (project != null) {
            task.setTaskId(nextTaskId++);
            project.getTasks().add(task);
        }
    }

    public void updateTask(int taskId, String name, String description, String status) {
        projects.values().forEach(project -> {
            project.getTasks().stream().filter(task -> task.getTaskId() == taskId).findFirst().ifPresent(task -> {
                task.setName(name);
                task.setDescription(description);
                task.setStatus(status);
            });
        });
    }

    public void deleteTask(int taskId) {
        projects.values().forEach(project -> project.getTasks().removeIf(task -> task.getTaskId() == taskId));
    }
}
