package com.mycompany.taskmanager.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Eskandar Atrakchi x23137517
 */

public class Project {
    private int projectId;
    private String name;
    private String description;
    // Using arrayList here 
    private List<Task> tasks = new ArrayList<>();

    // Getters and Setters
    
    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Task> getTasks() {
        return tasks;
    }

    public void setTasks(List<Task> tasks) {
        this.tasks = tasks;
    }
}
