package com.mycompany.taskmanager.resources;

import com.mycompany.taskmanager.model.Project;
import com.mycompany.taskmanager.model.Task;
import com.mycompany.taskmanager.services.ManagementService;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

//  @author Eskandar Atrakchi x23137517

@Path("/management")
public class ManagementResource {
    // Static instance to persist data
    private static final ManagementService service = new ManagementService(); 
    // The API key value on postman is 1234 and key in postman is ("API-Key")
    private static final String API_KEY = "1234";

    private boolean isValidApiKey(String apiKey) {
        return API_KEY.equals(apiKey);
    }
    // http://localhost:8080/TaskManager/api/management/projects 
    @GET
    @Path("/projects")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllProjects() {
        List<Project> projects = service.getAllProjects();
        //display all the projects 
        return Response.ok(projects).build();
    }

    @POST
    @Path("/projects")
    @Consumes(MediaType.APPLICATION_JSON)
    // the key in postman is ("API-Key") and its value is 1234
    public Response createProject(Project project, @HeaderParam("API-Key") String apiKey) {
        //scenario if the key is not valid 
        if (!isValidApiKey(apiKey)) {
            return Response.status(Response.Status.FORBIDDEN).entity("Invalid API Key").build();
        }
        //scenario if the project or project name is null 
        if (project == null || project.getName() == null)  {
            return Response.status(Response.Status.BAD_REQUEST).entity("Invalid project data").build();
        }
        service.createProject(project);
        return Response.status(Response.Status.CREATED).entity("Project created successfully").build();
    }

    @DELETE
    @Path("/projects/{id}")
    public Response deleteProject(@PathParam("id") int projectId, @HeaderParam("API-Key") String apiKey) {
        if (!isValidApiKey(apiKey)) {
            return Response.status(Response.Status.FORBIDDEN).entity("Invalid API Key").build();
        }
        service.deleteProject(projectId);
        return Response.ok("Project deleted successfully").build();
    }

    @POST
    @Path("/projects/{projectId}/tasks")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createTask(@PathParam("projectId") int projectId, Task task, @HeaderParam("API-Key") String apiKey) {
        if (!isValidApiKey(apiKey)) {
            return Response.status(Response.Status.FORBIDDEN).entity("Invalid API Key").build();
        }
        if (task == null || task.getName() == null) {
            return Response.status(Response.Status.BAD_REQUEST).entity("Invalid task data").build();
        }
        service.createTask(projectId, task);
        return Response.status(Response.Status.CREATED).entity("Task created successfully").build();
    }

    @GET
    @Path("/tasks")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllTasks() {
        List<Task> allTasks = service.getAllProjects().stream()
                .flatMap(project -> project.getTasks().stream())
                .toList();
        return Response.ok(allTasks).build();
    }
}
