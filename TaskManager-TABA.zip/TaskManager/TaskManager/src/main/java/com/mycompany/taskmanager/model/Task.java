package com.mycompany.taskmanager.model;

/**
 * @author Eskandar Atrakchi x23137517
 */

public class Task {
    private int taskId;
    private String name;
    private String description;
    private String status; // "pending" or "completed"

    // Getters and Setters
    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
